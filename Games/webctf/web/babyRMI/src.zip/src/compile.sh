#!/bin/bash
javac com/kaibro/rmi/Client.java com/kaibro/rmi/RMIInterface.java
