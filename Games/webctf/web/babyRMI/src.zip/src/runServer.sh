#!/bin/bash
cd /src
sudo -u nobody java com.kaibro.rmi.Server
