#!/bin/bash
javac -cp "deps/*:." com/kaibro/rmi/Client.java com/kaibro/rmi/RMIInterface.java
