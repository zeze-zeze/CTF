APP_ID = '[REDACTED]'
APP_PASSWORD = '[REDACTED]'
LOGDB = '[REDACTED]'

adminpwd = '[handed to each team seperately]'
