#!/bin/bash

pkill -2 gunicorn
