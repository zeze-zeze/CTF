(function () {
    var FireAlgorithm, data, fire, getCanvasContext, render, renderFire, setupCanvas;

    FireAlgorithm = class FireAlgorithm {
        constructor(width1, height, max) {
            var length;
            this.width = width1;
            this.height = height;
            this.max = max;
            // Get how many pixels the algorithm will interact
            // and create an array with that size.
            this.length = this.width * this.height;
            this.matrix = new Array(this.length).fill(0);
            this.ignite();
        }


        // Sets the last row of the table to the maximum value
        // to perpetuate the interaction of the pixels above.
        ignite() {
            var i, index, j, ref, results;
            results = [];
            for (i = j = 0, ref = this.width - 1; 0 <= ref ? j <= ref : j >= ref; i = 0 <= ref ? ++j : --j) {
                index = this.length - this.width + i;
                results.push(this.matrix[index] = this.max);
            }
            return results;
        }


        // For each pixel in the table, except the last line,
        // it takes the value of its pixel below and sets that value
        // to the pixel or some other to its left with a variable decay.
        update() {
            var decay, i, index, j, len, pixel, ref, results, value;
            ref = this.matrix;
            results = [];
            for (i = 0, len = ref.length; i < len; ++i) {
                pixel = ref[i]
                if (i < this.width) {
                    // Skip the last line of the table.
                    continue;
                }

                // Get the current pixel position.
                index = this.length - i - 1;

                // Generate the value decay between 0 and 3.
                decay = Math.floor(Math.random() * 3);

                // Get the value of the below pixel.
                value = this.matrix[index + this.width] - decay;

                // Set value to the pixel or some some other to its left.
                this.matrix[index - decay] = value > 0 ? value : 0
            }
        }

        stop() {
          for(var i = 0; i <= this.width; i++){
            var index = this.length - i;
            this.matrix[index] = 0;
          }
        }

        start() {
          for(var i = 0; i <= this.width; i++){
            var index = this.length - i;
            this.matrix[index] = 32;
          }
        }

        getData() {
            return this.matrix;
        }
    };




    // Initialize some canvas by setting its width
    // and height to the same values ​​as it parent.
    setupCanvas = function(selector) {
        var canvas, parent;
        canvas = document.querySelector(selector);
        parent = getComputedStyle(canvas.parentElement);
        canvas.width = parseInt(parent.width);
        return canvas.height = parseInt(parent.height);
    };


    // Quick method to get some canvas 2D context
    getCanvasContext = function(selector) {
        return document.querySelector(selector).getContext('2d');
    };

    renderFire = function(selector, width, pixels) {
        var colors, context, index, j, len, pixel, results, x, y;
        // Array of colors to give flameappearance
        // to the algorithm values.
        colors = ["#000000", "#1F0707", "#2F0F07", "#470F07", "#571707", "#671F07", "#771F07", "#8F2707", "#9F2F07", "#AF3F07", "#BF4707", "#C74707", "#DF4F07", "#DF4F07", "#D76008", "#D7670F", "#CF6F0E", "#CF770E", "#CF7F0E", "#CF8717", "#C78217", "#C78F17", "#C7971F", "#BF9F1F", "#BFA727", "#BFAF2F", "#B8B02F", "#B8B82F", "#B8B837", "#CFCF6F", "#DFDFA0", "#EEEEC7", "#FFF"];
        context = getCanvasContext(selector);

        // For each value of the algorithm matrix then draw
        // a 5x5 pixel in its respective position of the canvas.
        height = Math.floor(pixels.length / width);
        results = [];
        vw = window.innerWidth;
        vh = window.innerHeight;
        size = Math.max(vw / width, vh * 0.6 / height);
        off_y = vh - (pixels.length /width * size);
        for (index = 0, len = pixels.length; index < len; ++index) {
            pixel = pixels[index];
            x = index % width * size;
            y = Math.floor(index / width) * size;
            context.fillStyle = colors[pixel];
            results.push(context.fillRect(x, off_y + y, size, size));
        }
    };

    fire = new FireAlgorithm(240, 70, 32);

    data = fire.getData();

    setupCanvas('canvas#Fire');

    (render = function() {
        fire.update();
        renderFire('canvas#Fire', 240, data);
        setTimeout(()=>{requestAnimationFrame(render);}, 100);
    })();


    //# sourceURL=coffeescript
})()
