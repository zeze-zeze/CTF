#!/bin/bash
# exec 2>/dev/null
cd /home/messy_printer/task
./messy_printer use_argv_chain
read -p "done"
