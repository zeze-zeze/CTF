// 
// Decompiled by Procyon v0.5.36
// 

package Control;

import java.awt.Component;

public class Main
{
    public static void main(final String[] args) {
        final Frame fallen_beat = new Frame("Fallen Beat");
        fallen_beat.setSize(1280, 720);
        fallen_beat.setDefaultCloseOperation(3);
        fallen_beat.setLocationRelativeTo(null);
        fallen_beat.setResizable(false);
        fallen_beat.setVisible(true);
    }
}
