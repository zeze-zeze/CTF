// 
// Decompiled by Procyon v0.5.36
// 

package Visual;

import java.awt.Color;

public class MyColor
{
    public Color white;
    public Color yellow;
    public Color brown;
    public Color gray;
    public Color blue;
    
    public MyColor() {
        this.white = new Color(16187135);
        this.yellow = new Color(16772468);
        this.brown = new Color(11884100);
        this.gray = new Color(5529446);
        this.blue = new Color(5208751);
    }
}
