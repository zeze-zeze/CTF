Hi 
Key is generated using given binary with in one minute after compilation

valiadate key and get flag at : nc 35.231.63.121 1338

