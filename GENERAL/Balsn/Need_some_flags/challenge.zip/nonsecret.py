def printflag():
  flag="balsn{Absolutely_not_the_flag_you_want}"
  print flag
