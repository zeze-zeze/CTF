Hi 
My friend made a hash algo which he thought was irreversible....however he was on Manali Cream[hashish ;-)].
so he print something he should not print while making hashes.
Below is the output of given binary with flag as input... get the flag.

hash-0 : 138
hash-1 : 512
hash-2 : 1645
hash-3 : 5034
hash-4 : 15218
hash-5 : 45756
hash-6 : 137391
hash-7 : 412292
hash-8 : 1236927
hash-9 : 3710845
hash-10 : 11132642
hash-11 : 33398021
hash-12 : 100194167
hash-13 : 300582553
hash-14 : 901747774
hash-15 : 2705243426
hash-16 : 8115730373
hash-17 : 24347191171
hash-18 : 73041573621
hash-19 : 219124720917
hash-20 : 657374162799
hash-21 : 1972122488522
hash-22 : 5916367465576
