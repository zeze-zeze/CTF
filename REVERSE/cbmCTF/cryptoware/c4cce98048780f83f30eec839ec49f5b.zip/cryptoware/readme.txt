Hi
My girlfriend is new in hacking world and she is learning writing crypto ransomwares. After so much hardwork she managed to write one.She encrypt my seceret info file with her cryware. However she do not know much about encryption algorithm and used some crackable encryption. I have the executable binary of her cryware. Can you reverse it and decrypt the secretInfo file for me as I am too lazy for this stuff.
Thanks in advance ;-) 
