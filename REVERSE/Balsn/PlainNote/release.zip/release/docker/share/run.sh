#!/bin/bash
exec 2>/dev/null
timeout -k 5 300 /home/note/pow.py
